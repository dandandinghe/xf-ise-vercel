const crypto = require("crypto");
const axios = require("axios");
const multer = require("multer");
const express = require("express");
const app = express();
const upload = multer();

const APPID = "8597297a";
const APISecret = "MGY2YzU5OTE1MDA1OGMxYjg3ZjMxZjBh";
const APIKey = "58c1ae01c147542a62bd97f7f0fd9889";

function getWebSocketUrl() {
  const date = new Date().toUTCString();
  const signatureOrigin = `host: ws-api.xfyun.cn\ndate: ${date}\nGET /v2/ise HTTP/1.1`;
  const signatureSha = crypto.createHmac("sha256", APISecret).update(signatureOrigin).digest("base64");
  const authorizationOrigin = `api_key=\"${APIKey}\", algorithm=\"hmac-sha256\", headers=\"host date request-line\", signature=\"${signatureSha}\"`;
  const authBase64 = Buffer.from(authorizationOrigin).toString("base64");

  return `wss://ws-api.xfyun.cn/v2/ise?authorization=${authBase64}&date=${encodeURIComponent(date)}&host=ws-api.xfyun.cn`;
}

module.exports = (req, res) => {
  if (req.method === "POST") {
    upload.single("audio")(req, res, function (err) {
      if (err || !req.file) {
        return res.status(400).json({ error: "Missing or invalid audio file." });
      }
      const base64Audio = req.file.buffer.toString("base64");
      const wsUrl = getWebSocketUrl();
      return res.status(200).json({ success: true, wsUrl, audio: base64Audio });
    });
  } else {
    res.status(405).json({ error: "Method not allowed" });
  }
};
