// 文件路径：/api/eval.js

import crypto from "crypto";
import formidable from "formidable";
import { readFile } from "fs/promises";

// 禁止默认 body parser
export const config = {
  api: {
    bodyParser: false,
  },
};

const APPID = "8597297a";
const APISecret = "MGY2YzU5OTE1MDA1OGMxYjg3ZjMxZjBh";
const APIKey = "58c1ae01c147542a62bd97f7f0fd9889";

function getWebSocketUrl() {
  const date = new Date().toUTCString();
  const signatureOrigin = `host: ws-api.xfyun.cn\ndate: ${date}\nGET /v2/ise HTTP/1.1`;
  const signatureSha = crypto.createHmac("sha256", APISecret).update(signatureOrigin).digest("base64");
  const authorizationOrigin = `api_key="${APIKey}", algorithm="hmac-sha256", headers="host date request-line", signature="${signatureSha}"`;
  const authBase64 = Buffer.from(authorizationOrigin).toString("base64");

  return `wss://ws-api.xfyun.cn/v2/ise?authorization=${authBase64}&date=${encodeURIComponent(date)}&host=ws-api.xfyun.cn`;
}

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const form = formidable({ multiples: false });
  form.parse(req, async (err, fields, files) => {
    if (err || !files.audio) {
      return res.status(400).json({ error: "Missing or invalid audio file." });
    }

    const fileData = await readFile(files.audio.filepath);
    const base64Audio = fileData.toString("base64");
    const wsUrl = getWebSocketUrl();

    return res.status(200).json({ success: true, wsUrl, audio: base64Audio });
  });
}
